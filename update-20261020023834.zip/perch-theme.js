/* perch-theme.js — The Perch theme engine, shared by the home screen and every tool.
   Each theme fills the same slots the tools already use (bg, surface, text, accent…),
   plus `disc`/`ink` for the owl logo. The active theme id stays in localStorage "bench_theme".
   Kid colors (Full house) live in "perch_kids"; theme mode/favorites in "perch_theme_mode"/"perch_theme_favs". */
(function () {
  "use strict";

  var KIDS = [
    { name: "Jaylan", pet: "Schnack", color: "#2f6fb3" },
    { name: "Jade", pet: "Choums", color: "#e8689a" },
    { name: "Gianna", pet: "Twoose", color: "#f2c233" },
    { name: "Jax", pet: "Schmalls", color: "#d23b3b" }
  ];

  function rgba(hex, a) {
    var h = hex.replace("#", "");
    return "rgba(" + parseInt(h.slice(0, 2), 16) + "," + parseInt(h.slice(2, 4), 16) + "," + parseInt(h.slice(4, 6), 16) + "," + a + ")";
  }

  // Solid blend of two hex colors (t = share of b). OUTWORK and Ledger need solid colors, not rgba.
  function mix(a, b, t) {
    var x = a.replace("#", ""), y = b.replace("#", ""), out = "#";
    for (var i = 0; i < 6; i += 2) {
      var v = Math.round(parseInt(x.slice(i, i + 2), 16) * (1 - t) + parseInt(y.slice(i, i + 2), 16) * t);
      out += ("0" + v.toString(16)).slice(-2);
    }
    return out;
  }

  // Build the full slot set the tools expect from a few base colors.
  function make(id, name, tagline, bg, text, accent, disc, ink) {
    return {
      id: id, name: name, tagline: tagline,
      bg: bg, text: text, accent: accent, disc: disc, ink: ink || bg,
      textSec: rgba(text, 0.82), textMuted: rgba(text, 0.5),
      surface: rgba(text, 0.06), surfaceHi: rgba(accent, 0.2),
      border: rgba(text, 0.1), borderHi: rgba(accent, 0.55),
      card: rgba(text, 0.045), cardBorder: rgba(text, 0.1),
      pulseBar: rgba(accent, 0.08), header: rgba(bg, 0.96),
      // solid versions of the same slots
      surfaceSolid: mix(bg, text, 0.06), surface2Solid: mix(bg, text, 0.1),
      borderSolid: mix(bg, text, 0.16), textSecSolid: mix(bg, text, 0.72), mutedSolid: mix(bg, text, 0.5)
    };
  }

  function kidColors() {
    try {
      var v = JSON.parse(localStorage.getItem("perch_kids") || "null");
      if (Array.isArray(v) && v.length === 4) return v;
    } catch (e) { /* fall through */ }
    return KIDS.map(function (k) { return k.color; });
  }
  function fullHouseDisc(c) {
    return "conic-gradient(" + c[0] + " 0 25%," + c[1] + " 0 50%," + c[2] + " 0 75%," + c[3] + " 0)";
  }

  // What each theme means, shown on the home screen under "Today's theme".
  var MEANINGS = {
    brick: "Fired brick, mortar grey and charcoal, straight from your creed. The red is a nod to Trinidad. Build on purpose, one brick a day.",
    pan: "Trinidad built the steelpan out of oil drums. Polished pan silver under a warm stage light, for the singer in you.",
    hoo: "Knock knock. Sunny yellow and deep teal. The owl is still wise, it just tells better jokes today.",
    gemini: "The circle splits in two: concrete and slate, Kerwin and Jōshua, day and night. The brass owl sits across both halves, because it's the same bird either way.",
    fullhouse: "One quarter for each kid, clockwise from the eldest: Jaylan, Jade, Gianna, Jax. Four quarters, one roof. The owl doesn't do favorites."
  };

  function all() {
    return withMeanings([
      make("brick", "Brick and mortar", "Every day is a brick", "#2a2d31", "#e6e7e8", "#d9806a", "#a4452f"),
      make("pan", "Steel pan", "Music, made in Trinidad", "#1d2024", "#e6e7e8", "#f2a33a", "#cfd4d9"),
      make("hoo", "Hoo's there?", "The comedian", "#173b3a", "#f7efe0", "#f5c53d", "#f5c53d"),
      make("gemini", "Gemini", "Two of you, one owl", "#2b3036", "#e6e7e8", "#c9a24a",
        "linear-gradient(90deg,#e6e7e8 50%,#465059 50%)", "#c9a24a"),
      make("fullhouse", "Full house", "Four quarters, one roof", "#1f2226", "#e6e7e8", "#c9a24a", fullHouseDisc(kidColors()))
    ]);
  }
  function withMeanings(list) {
    list.forEach(function (t) { t.meaning = MEANINGS[t.id] || ""; });
    return list;
  }

  function get(id) {
    var list = all();
    for (var i = 0; i < list.length; i++) if (list[i].id === id) return list[i];
    return list[0];
  }
  function currentId() {
    var id = localStorage.getItem("bench_theme");
    return all().some(function (t) { return t.id === id; }) ? id : "brick";
  }
  function set(id) { localStorage.setItem("bench_theme", id); }

  function mode() { return localStorage.getItem("perch_theme_mode") || "shuffle"; }
  function setMode(m) { localStorage.setItem("perch_theme_mode", m); }
  function favorites() {
    var ids = all().map(function (t) { return t.id; });
    try {
      var v = JSON.parse(localStorage.getItem("perch_theme_favs") || "null");
      if (Array.isArray(v)) { v = v.filter(function (x) { return ids.indexOf(x) >= 0; }); if (v.length) return v; }
    } catch (e) { /* fall through */ }
    return ids;
  }
  function setFavorites(v) { localStorage.setItem("perch_theme_favs", JSON.stringify(v)); }

  // Called once when the app opens: Surprise me picks a different favorite than last time.
  function pickOnLaunch() {
    var m = mode();
    if (m !== "shuffle") { set(get(m).id); return; }
    var favs = favorites(), last = localStorage.getItem("bench_theme");
    var pool = favs.length > 1 ? favs.filter(function (x) { return x !== last; }) : favs;
    set(pool[Math.floor(Math.random() * pool.length)]);
  }
  function next() {
    var favs = favorites(), i = favs.indexOf(currentId());
    set(favs[(i + 1) % favs.length]);
    return get(currentId());
  }

  function setKidColor(i, hex) {
    var c = kidColors().slice();
    c[i] = hex;
    localStorage.setItem("perch_kids", JSON.stringify(c));
  }

  // Owl logo as an HTML string: circle (disc) behind the recolorable owl silhouette.
  function logo(size, theme) {
    var t = theme || get(currentId());
    return "<div aria-hidden='true' style='position:relative;width:" + size + "px;height:" + size + "px;flex-shrink:0;'>"
      + "<div style='position:absolute;inset:2.2%;border-radius:50%;background:" + t.disc + ";'></div>"
      + "<div style='position:absolute;inset:0;background:" + t.ink + ";-webkit-mask:url(perch-mark.png) center/contain no-repeat;mask:url(perch-mark.png) center/contain no-repeat;'></div>"
      + "</div>";
  }

  // Device sync bookkeeping: remember WHEN each saved value last changed on this device, so
  // perch-sync.js can send only what changed and the newest copy wins between phone and tablet.
  // Every Perch page loads this file, so every tool's saves get stamped.
  var LOCAL_ONLY = /^(hushbox_|bench_pin|perch_board_|perch_sync_|perch_last_sync|perch_bio_|perch_device_|perch_data_|__perch|ow_last_error|ow2_tab$|tab$|bench_theme$|__owtest)/;
  function syncable(k) { return typeof k === "string" && !LOCAL_ONLY.test(k); }
  try {
    var S = window.Storage && window.Storage.prototype;
    if (S && !S.__perchStamped) {
      var origSet = S.setItem, origRemove = S.removeItem, origGet = S.getItem;
      var stamp = function (store, k) {
        if (store !== window.localStorage || !syncable(k)) return;
        try {
          var m = JSON.parse(origGet.call(store, "__perch_mtimes") || "{}");
          m[k] = Date.now();
          origSet.call(store, "__perch_mtimes", JSON.stringify(m));
        } catch (e) { /* never block a save */ }
      };
      S.setItem = function (k, v) {
        var before = origGet.call(this, k);
        origSet.call(this, k, v);
        if (before !== String(v)) stamp(this, k);
      };
      S.removeItem = function (k) {
        var had = origGet.call(this, k) !== null;
        origRemove.call(this, k);
        if (had) stamp(this, k);
      };
      S.__perchOrig = { set: origSet, remove: origRemove, get: origGet };
      S.__perchStamped = true;
    }
  } catch (e) { /* storage blocked */ }

  // Back to The Perch home screen. Tools run inside the home screen's frame, so close the frame;
  // going "back" in history inside the frame lands on an empty page (the old black-screen bug).
  var framed = window.parent && window.parent !== window;
  function home() {
    try { if (framed && window.parent.closeTool) { window.parent.closeTool(); return; } } catch (e) { /* not reachable */ }
    location.href = "index.html";
  }
  // Inside the frame the home screen already shows "← Home", so hide each tool's own back arrow.
  if (framed) {
    var st = document.createElement("style");
    st.textContent = 'button[onclick^="PerchTheme.home"]{visibility:hidden!important;}';
    (document.head || document.documentElement).appendChild(st);
  }

  window.PerchTheme = {
    KIDS: KIDS, list: all, get: get, currentId: currentId, set: set,
    mode: mode, setMode: setMode, favorites: favorites, setFavorites: setFavorites,
    pickOnLaunch: pickOnLaunch, next: next, kidColors: kidColors, setKidColor: setKidColor,
    fullHouseDisc: fullHouseDisc, logo: logo, mix: mix, home: home, syncable: syncable
  };
})();
