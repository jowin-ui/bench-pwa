/* perch-sync.js — sends a daily snapshot of The Perch to the display board over home Wi-Fi.
   Pairing (board address + sync key, both shown in the board's Settings) is saved on the phone.
   Sent: habits, routines, focus minutes, Unstuck picks, The Nest, theme + kids' colors,
   and journal dates/word counts only (never journal text). Ledger and OUTWORK are never sent. */
(function () {
  "use strict";

  function ls(k, d) { try { var v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch (e) { return d; } }
  function raw(k) { try { return localStorage.getItem(k) || ""; } catch (e) { return ""; } }
  function setRaw(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* storage blocked */ } }
  function dayKey(offset) { return new Date(Date.now() - (offset || 0) * 86400000).toISOString().slice(0, 10); }

  // Same defaults the tools use when nothing has been saved yet.
  var DEFAULT_HABITS = [{ id: "h1", name: "Hydrate 2L" }, { id: "h2", name: "Exercise" }, { id: "h3", name: "Read 20 min" }, { id: "h4", name: "No alcohol" }, { id: "h5", name: "Sleep by 10pm" }];
  var DEFAULT_MORNING = [{ id: "m1", label: "Hydrate — 500ml water" }, { id: "m2", label: "5 min breathwork" }, { id: "m3", label: "Review today's priorities" }, { id: "m4", label: "10 min movement" }, { id: "m5", label: "Cold shower" }];
  var DEFAULT_EVENING = [{ id: "e1", label: "Reflect on the day" }, { id: "e2", label: "Plan tomorrow" }, { id: "e3", label: "No screens 30 min" }, { id: "e4", label: "Read 20 min" }, { id: "e5", label: "Lights out by 10pm" }];

  function buildSnapshot() {
    var today = dayKey(0);
    var habits = ls("habits_list", DEFAULT_HABITS).map(function (h) { return { id: h.id, name: h.name, emoji: h.emoji || "" }; });
    var habitDays = {};
    for (var i = 0; i < 14; i++) habitDays[dayKey(i)] = ls("habits_log_" + dayKey(i), {});

    var focusDays = {};
    for (var j = 0; j < 7; j++) {
      focusDays[dayKey(j)] = ls("focus_sessions_" + dayKey(j), []).reduce(function (s, x) { return s + (x.mins || 0); }, 0);
    }

    var tasks = ls("unstuck_tasks", []);
    var pick = ls("unstuck_today_pick", null);
    var pickTasks = pick && pick.taskIds ? pick.taskIds.map(function (id) {
      var t = tasks.filter(function (x) { return x.id === id; })[0];
      return t ? { title: t.title, done: !!t.done } : null;
    }).filter(Boolean) : [];

    var journal = ls("journal_entries", []).slice(0, 30).map(function (e) {
      var words = [e.gratitude, e.reflection, e.note].join(" ").trim();
      return { date: e.date, mood: e.mood || "", words: words ? words.split(/\s+/).length : 0 };
    });

    var nest = ls("perch_nest", { people: [] });
    var kids = window.PerchTheme ? window.PerchTheme.kidColors() : null;
    nest.people = (nest.people || []).map(function (p) {
      var c = typeof p.slot === "number" && kids ? kids[p.slot] : p.color;
      return Object.assign({}, p, { color: c });
    });

    return {
      version: 1,
      sentAt: new Date().toISOString(),
      day: today,
      theme: { id: raw("bench_theme"), kids: kids },
      habits: { list: habits, today: habitDays[today], days: habitDays },
      routines: {
        morning: { steps: ls("routine_morning", DEFAULT_MORNING), done: ls("routine_log_morning_" + today, {}) },
        evening: { steps: ls("routine_evening", DEFAULT_EVENING), done: ls("routine_log_evening_" + today, {}) }
      },
      focus: { todayMins: focusDays[today], days: focusDays },
      unstuck: { todayPick: pick ? { date: pick.date, tasks: pickTasks } : null, openCount: tasks.filter(function (t) { return !t.done; }).length },
      journal: journal,
      nest: nest
    };
  }

  function normalizeAddress(a) {
    a = String(a || "").trim().replace(/^https?:\/\//i, "").replace(/\/+$/, "");
    if (a && !/:\d+$/.test(a)) a += ":3000";
    return a;
  }

  var listeners = [];
  function notify() { listeners.forEach(function (fn) { try { fn(); } catch (e) { /* ignore */ } }); }

  function state() {
    return {
      address: raw("perch_board_addr"),
      key: raw("perch_board_key"),
      lastSync: raw("perch_last_sync"),
      message: raw("perch_sync_msg"),
      ok: raw("perch_sync_ok") === "1"
    };
  }

  var busy = false;
  // force=false skips the send if the last good sync was under 2 minutes ago.
  function syncNow(force) {
    var s = state();
    if (!s.address || !s.key || busy) return Promise.resolve(false);
    if (!force && s.ok && s.lastSync && Date.now() - new Date(s.lastSync).getTime() < 2 * 60 * 1000) return Promise.resolve(false);
    busy = true;
    var ctrl = window.AbortController ? new AbortController() : null;
    var timer = setTimeout(function () { if (ctrl) ctrl.abort(); }, 8000);
    return fetch("http://" + s.address + "/api/perch/snapshot", {
      method: "POST",
      headers: { "Content-Type": "application/json", "X-Perch-Key": s.key },
      body: JSON.stringify(buildSnapshot()),
      signal: ctrl ? ctrl.signal : undefined
    }).then(function (res) {
      return res.json().catch(function () { return {}; }).then(function (j) {
        if (!res.ok) throw new Error(j.error || ("The board answered " + res.status));
        setRaw("perch_last_sync", new Date().toISOString());
        setRaw("perch_sync_ok", "1");
        setRaw("perch_sync_msg", "Synced");
        return true;
      });
    }).catch(function (err) {
      setRaw("perch_sync_ok", "0");
      setRaw("perch_sync_msg", err && err.name === "AbortError"
        ? "Couldn't reach the board. Are you on home Wi-Fi?"
        : (err && /fetch|network/i.test(err.message) ? "Couldn't reach the board. Check the address and that you're on home Wi-Fi." : (err && err.message) || "Sync failed"));
      return false;
    }).then(function (r) { clearTimeout(timer); busy = false; notify(); return r; });
  }

  function pair(address, key) {
    setRaw("perch_board_addr", normalizeAddress(address));
    setRaw("perch_board_key", String(key || "").trim().toUpperCase());
    setRaw("perch_sync_ok", "0");
    setRaw("perch_sync_msg", "");
    return syncNow(true);
  }

  // Sync when the app opens, every 15 minutes while it's open, and when a tool closes.
  setTimeout(function () { syncNow(false); }, 2500);
  setInterval(function () { syncNow(true); }, 15 * 60 * 1000);
  document.addEventListener("visibilitychange", function () { if (!document.hidden) syncNow(false); });

  window.PerchSync = { buildSnapshot: buildSnapshot, syncNow: syncNow, pair: pair, state: state, onChange: function (fn) { listeners.push(fn); } };
})();
