/* lock.js — PIN lock for The Perch.
   - First open: create a 4-digit PIN, then write down a one-time recovery code.
   - Asks for the PIN every time the app opens, and after it has been in the background for a minute.
   - 5 wrong tries = 30 s wait, 10 = 5 min wait.
   - Forgot PIN: enter the recovery code to set a new PIN. Your data is never erased by the lock.
   - Fingerprint / face unlock (optional): uses the phone's own biometrics through the
     capacitor-native-biometric plugin, same as the Command Center. The PIN always still works.
   The PIN and code are stored only as salted hashes on this phone. */
(function () {
  "use strict";
  var K = { pin: "bench_pin_v1", fails: "bench_pin_fails", until: "bench_pin_until", hidden: "bench_pin_hidden_at", off: "bench_pin_off", bio: "perch_bio_on" };
  var AWAY_MS = 60 * 1000;
  function get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }
  function put(k, v) { try { if (v == null) localStorage.removeItem(k); else localStorage.setItem(k, v); } catch (e) {} }
  function rec() { try { return JSON.parse(get(K.pin) || "null"); } catch (e) { return null; } }

  function hash(s) {
    var data = new TextEncoder().encode(String(s) + "|bench_salt_v1");
    try {
      return crypto.subtle.digest("SHA-256", data).then(function (b) {
        return Array.prototype.map.call(new Uint8Array(b), function (x) { return ("0" + x.toString(16)).slice(-2); }).join("");
      }).catch(fallback);
    } catch (e) { return Promise.resolve(fallback()); }
    function fallback() { var h = 0, t = String(s) + "|bench_salt_v1"; for (var i = 0; i < t.length; i++) h = Math.imul(31, h) + t.charCodeAt(i) | 0; return "fb_" + (h >>> 0).toString(16); }
  }
  function newCode() {
    var A = "ABCDEFGHJKMNPQRSTUVWXYZ23456789", out = "", r = new Uint32Array(8);
    try { crypto.getRandomValues(r); } catch (e) { for (var j = 0; j < 8; j++) r[j] = Math.floor(Math.random() * 1e9); }
    for (var i = 0; i < 8; i++) out += A[r[i] % A.length];
    return out.slice(0, 4) + "-" + out.slice(4);
  }
  /* ---------- fingerprint / face ---------- */
  function bioPlugin() { try { return window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.NativeBiometric; } catch (e) { return null; } }
  function bioAvailable() {
    var p = bioPlugin(); if (!p) return Promise.resolve(false);
    return p.isAvailable().then(function (r) { return !!(r && r.isAvailable); }).catch(function () { return false; });
  }
  function bioOn() { return get(K.bio) === "1"; }
  function bioVerify() {
    var p = bioPlugin(); if (!p) return Promise.reject(new Error("no biometrics"));
    return p.verifyIdentity({ reason: "Unlock The Perch", title: "Unlock The Perch", subtitle: "Use your fingerprint or face", negativeButtonText: "Use PIN" });
  }
  var bioReady = false, bioTried = false;
  bioAvailable().then(function (ok) { bioReady = ok; if (isShown()) draw(); });
  function tryBio() {
    if (!bioReady || !bioOn() || busy) return;
    busy = true;
    bioVerify().then(function () { busy = false; put(K.fails, null); put(K.until, null); done(); })
      .catch(function () { busy = false; msg = ""; draw(); });
  }

  function T() { try { return window.gT ? window.gT() : null; } catch (e) { return null; } }

  /* ---------- the screen ---------- */
  var box = null, mode = "enter", first = "", entry = "", msg = "", busy = false, timer = null, pendingCode = "";
  function colors() {
    var t = T() || {};
    return { bg: t.bg || "#141412", text: t.text || "#DFDAD1", muted: t.textMuted || "rgba(209,205,191,.4)", accent: t.accent || "#92948D", surface: t.surface || "rgba(223,218,209,.06)", border: t.border || "rgba(223,218,209,.1)" };
  }
  function lockedFor() { var u = +get(K.until) || 0; return Math.max(0, Math.ceil((u - Date.now()) / 1000)); }

  function show(m) {
    mode = m; first = ""; entry = ""; msg = ""; bioTried = false;
    if (!box) {
      box = document.createElement("div"); box.id = "bench-lock";
      box.setAttribute("role", "dialog"); box.setAttribute("aria-label", "The Perch is locked");
      document.body.appendChild(box);
      box.addEventListener("click", onTap);
    }
    box.style.display = "flex";
    draw();
    if (m === "enter") setTimeout(function () { if (!bioTried) { bioTried = true; tryBio(); } }, 350);
  }
  function hide() { if (box) box.style.display = "none"; clearInterval(timer); timer = null; }
  function isShown() { return !!box && box.style.display !== "none"; }

  function title() {
    return { bio: "Unlock faster?", enter: "Enter your PIN", create: "Create a PIN", confirm: "Enter it again", code: "Recovery code", recover: "Forgot your PIN?", oldpin: "Enter your current PIN", off: "Enter your PIN to turn the lock off" }[mode];
  }
  function sub() {
    if (mode === "create") return "4 digits. You’ll enter it each time you open The Perch.";
    if (mode === "confirm") return "Type the same 4 digits to confirm.";
    if (mode === "recover") return "Type the recovery code you wrote down when you made your PIN.";
    if (mode === "enter") return "The Perch is locked.";
    if (mode === "bio") return "Use your fingerprint or face to open The Perch. Your PIN still works anytime.";
    return "";
  }

  function draw() {
    if (!box) return;
    var c = colors();
    box.style.cssText = "position:fixed;inset:0;z-index:100000;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:0;padding:24px 20px calc(24px + env(safe-area-inset-bottom,0px));background:" + c.bg + ";color:" + c.text + ";font-family:system-ui,-apple-system,sans-serif;user-select:none;-webkit-user-select:none;";
    var wait = lockedFor();
    var h = "<div style='font-size:9px;letter-spacing:.22em;text-transform:uppercase;color:" + c.muted + ";margin-bottom:8px;'>The Perch</div>";
    h += "<div style='font-size:22px;font-weight:800;margin-bottom:6px;text-align:center;'>" + title() + "</div>";
    h += "<div style='font-size:12px;color:" + c.muted + ";min-height:18px;text-align:center;max-width:280px;line-height:1.5;'>" + sub() + "</div>";

    if (mode === "code") {
      h += "<div style='margin:22px 0 10px;font:700 30px/1 ui-monospace,Menlo,monospace;letter-spacing:3px;padding:16px 18px;border:1px dashed " + c.accent + ";border-radius:12px;'>" + pendingCode + "</div>";
      h += "<div style='font-size:13px;line-height:1.55;max-width:300px;text-align:center;color:" + c.text + ";'>Write this down or take a screenshot and keep it somewhere safe. If you ever forget your PIN, this code lets you set a new one without losing anything. It won’t be shown again.</div>";
      h += btn("codeDone", "I saved it", true, c);
      return set(h);
    }
    if (mode === "bio") {
      h += btn("bioYes", "Use fingerprint / face", true, c) + btn("bioNo", "Not now", false, c);
      return set(h);
    }
    if (mode === "recover") {
      h += "<input id='bench-rc' autocomplete='off' autocapitalize='characters' spellcheck='false' placeholder='XXXX-XXXX' style='margin:22px 0 6px;font:700 22px/1 ui-monospace,Menlo,monospace;letter-spacing:2px;text-align:center;width:220px;padding:12px;border-radius:10px;border:1px solid " + c.border + ";background:" + c.surface + ";color:" + c.text + ";text-transform:uppercase;'>";
      h += "<div style='font-size:12px;color:#e07a5f;min-height:18px;margin-bottom:4px;'>" + esc(msg) + "</div>";
      h += btn("rcCheck", "Use code", true, c) + btn("rcBack", "Back", false, c);
      return set(h, function () { var i = document.getElementById("bench-rc"); if (i) i.focus(); });
    }

    var len = (mode === "confirm" ? entry : entry).length;
    h += "<div style='display:flex;gap:16px;margin:22px 0 8px;'>";
    for (var i = 0; i < 4; i++) h += "<div style='width:15px;height:15px;border-radius:50%;border:1.5px solid " + c.accent + ";background:" + (i < len ? c.accent : "transparent") + ";'></div>";
    h += "</div>";
    h += "<div style='font-size:12px;color:#e07a5f;min-height:18px;margin-bottom:10px;text-align:center;'>" + esc(wait ? "Too many tries. Wait " + wait + " s." : msg) + "</div>";
    h += "<div style='display:grid;grid-template-columns:repeat(3,72px);gap:12px;'>";
    ["1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", "del"].forEach(function (k) {
      if (!k) { h += "<div></div>"; return; }
      h += "<button data-k='" + k + "' " + (wait ? "disabled " : "") + "style='height:72px;border-radius:50%;border:0.5px solid " + c.border + ";background:" + (k === "del" ? "transparent" : c.surface) + ";color:" + c.text + ";font-size:" + (k === "del" ? "18px" : "24px") + ";font-weight:600;opacity:" + (wait ? .4 : 1) + ";' aria-label='" + (k === "del" ? "Delete" : k) + "'>" + (k === "del" ? "⌫" : k) + "</button>";
    });
    h += "</div>";
    if (mode === "enter" && bioReady && bioOn()) h += btn("bioTry", "Use fingerprint / face", false, c);
    if (mode === "enter") h += "<button data-a='forgot' style='margin-top:22px;background:none;border:0;color:" + c.muted + ";font-size:12px;text-decoration:underline;'>Forgot PIN?</button>";
    if (mode === "oldpin" || mode === "off" || (mode === "create" && rec())) h += "<button data-a='cancel' style='margin-top:22px;background:none;border:0;color:" + c.muted + ";font-size:12px;text-decoration:underline;'>Cancel</button>";
    set(h);
    if (wait && !timer) timer = setInterval(function () { if (!lockedFor()) { clearInterval(timer); timer = null; } draw(); }, 1000);
  }
  function btn(a, label, primary, c) {
    return "<button data-a='" + a + "' style='display:block;margin:14px auto 0;min-width:180px;padding:12px 18px;border-radius:12px;font-size:14px;font-weight:700;border:0.5px solid " + c.border + ";background:" + (primary ? c.accent : "transparent") + ";color:" + (primary ? c.bg : c.text) + ";'>" + label + "</button>";
  }
  function set(h, after) { box.innerHTML = h; if (after) after(); }
  function esc(s) { return String(s || "").replace(/[&<>"']/g, function (m) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[m]; }); }

  function onTap(e) {
    var t = e.target.closest ? e.target.closest("button") : null; if (!t || t.disabled || busy) return;
    var k = t.getAttribute("data-k"), a = t.getAttribute("data-a");
    if (k) {
      if (lockedFor()) return;
      msg = "";
      if (k === "del") entry = entry.slice(0, -1); else if (entry.length < 4) entry += k;
      draw();
      if (entry.length === 4) setTimeout(submit, 120);
      return;
    }
    if (a === "forgot") { mode = "recover"; msg = ""; draw(); }
    else if (a === "rcBack") { mode = "enter"; msg = ""; entry = ""; draw(); }
    else if (a === "rcCheck") checkCode();
    else if (a === "codeDone") { pendingCode = ""; if (bioReady && !bioOn()) { mode = "bio"; draw(); } else done(); }
    else if (a === "bioTry") { tryBio(); }
    else if (a === "bioYes") { busy = true; bioVerify().then(function () { busy = false; put(K.bio, "1"); done(); toastMsg("Fingerprint / face unlock is on"); }).catch(function () { busy = false; msg = "That didn't work. You can turn it on later from the lock menu."; draw(); }); }
    else if (a === "bioNo") { done(); }
    else if (a === "cancel") { hide(); }
  }

  function wrong() {
    var f = (+get(K.fails) || 0) + 1; put(K.fails, String(f));
    if (f >= 10) put(K.until, String(Date.now() + 5 * 60 * 1000));
    else if (f >= 5 && f % 5 === 0) put(K.until, String(Date.now() + 30 * 1000));
    msg = "Wrong PIN."; entry = ""; draw();
  }
  function submit() {
    var r = rec(), pin = entry; busy = true;
    if (mode === "create") { first = pin; entry = ""; mode = "confirm"; busy = false; draw(); return; }
    if (mode === "confirm") {
      busy = false;
      if (pin !== first) { mode = "create"; first = ""; entry = ""; msg = "Those didn’t match. Try again."; draw(); return; }
      pendingCode = newCode();
      busy = true;
      Promise.all([hash(pin), hash(pendingCode.replace(/-/g, ""))]).then(function (hs) {
        put(K.pin, JSON.stringify({ h: hs[0], rc: hs[1], made: Date.now() })); put(K.off, null);
        put(K.fails, null); put(K.until, null);
        busy = false; mode = "code"; draw();
      });
      return;
    }
    hash(pin).then(function (h) {
      busy = false;
      if (!r || h !== r.h) return wrong();
      put(K.fails, null); put(K.until, null);
      if (mode === "oldpin") { mode = "create"; entry = ""; first = ""; msg = ""; draw(); return; }
      if (mode === "off") { put(K.pin, null); put(K.off, "1"); hide(); toastMsg("PIN lock turned off"); return; }
      if (bioReady && !bioOn() && get("perch_bio_asked") !== "1") { put("perch_bio_asked", "1"); mode = "bio"; entry = ""; draw(); return; }
      done();
    });
  }
  function checkCode() {
    var i = document.getElementById("bench-rc"); var v = (i ? i.value : "").toUpperCase().replace(/[^A-Z0-9]/g, "");
    var r = rec(); if (!r || v.length !== 8) { msg = "Enter all 8 characters."; draw(); return; }
    if (lockedFor()) { msg = "Too many tries. Wait " + lockedFor() + " s."; draw(); return; }
    hash(v).then(function (h) {
      if (h !== r.rc) { var f = (+get(K.fails) || 0) + 1; put(K.fails, String(f)); if (f >= 5 && f % 5 === 0) put(K.until, String(Date.now() + 30 * 1000)); msg = "That code doesn’t match."; draw(); return; }
      put(K.fails, null); put(K.until, null);
      mode = "create"; entry = ""; first = ""; msg = "Code accepted. Make a new PIN."; draw();
    });
  }
  function done() { hide(); }
  function toastMsg(s) {
    var d = document.createElement("div"); var c = colors();
    d.textContent = s; d.style.cssText = "position:fixed;left:50%;bottom:calc(24px + env(safe-area-inset-bottom,0px));transform:translateX(-50%);z-index:100001;background:" + c.text + ";color:" + c.bg + ";padding:9px 14px;border-radius:10px;font:600 13px system-ui,sans-serif;";
    document.body.appendChild(d); setTimeout(function () { d.remove(); }, 2200);
  }

  /* ---------- public: for the 🔒 menu on the home screen ---------- */
  window.BenchLock = {
    hasPin: function () { return !!rec(); },
    lockNow: function () { if (rec()) show("enter"); else show("create"); },
    change: function () { if (rec()) show("oldpin"); else show("create"); },
    turnOff: function () { if (rec()) show("off"); },
    bioAvailable: function () { return bioReady; },
    bioOn: bioOn,
    setBio: function (on) {
      if (!on) { put(K.bio, null); toastMsg("Fingerprint / face unlock is off"); return Promise.resolve(false); }
      return bioVerify().then(function () { put(K.bio, "1"); toastMsg("Fingerprint / face unlock is on"); return true; }).catch(function () { return false; });
    },
    isLocked: isShown
  };

  /* ---------- when to lock ---------- */
  function start() { if (rec()) show("enter"); else if (!get(K.off)) show("create"); }
  document.addEventListener("visibilitychange", function () {
    if (document.hidden) { put(K.hidden, String(Date.now())); return; }
    var at = +get(K.hidden) || 0;
    if (rec() && at && Date.now() - at >= AWAY_MS && !isShown()) show("enter");
  });
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start); else start();
})();
