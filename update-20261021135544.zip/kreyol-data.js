/* kreyol-data.js: lessons for The Perch's Kreyòl tool (2026-10-20).
   Level: upper A1 (Duolingo Section 3). Weak spots first: tense markers, nou vs. ou,
   articles (la / a / an / nan), question words. Written by Claude; worth a tutor's review.
   Card types:
     fill: a sentence with ___ ; pick the right word (opts).
     tr:   translate; pick the right Kreyòl (distractors come from the same tag). */
window.KREYOL = {
  tags: {
    markers: "Tense markers",
    pronouns: "Pronouns",
    articles: "“The” (la / a / an / nan)",
    questions: "Question words",
    little: "Little words",
    travel: "Travel together",
    everyday: "Everyday phrases"
  },
  cards: [
    /* ---- tense markers: te / ap / pral / va ---- */
    { id: "m1", tag: "markers", type: "fill", q: "Yè mwen ___ manje diri.", a: "te", opts: ["te", "ap", "pral", "va"], en: "Yesterday I ate rice." },
    { id: "m2", tag: "markers", type: "fill", q: "Kounye a nou ___ travay.", a: "ap", opts: ["te", "ap", "pral", "va"], en: "Right now we're working." },
    { id: "m3", tag: "markers", type: "fill", q: "Demen li ___ vini.", a: "pral", opts: ["te", "ap", "pral", "se"], en: "Tomorrow he's going to come." },
    { id: "m4", tag: "markers", type: "fill", q: "Ane pwochen m ___ vizite Ayiti.", a: "va", opts: ["te", "ap", "va", "ye"], en: "Next year I will visit Haiti." },
    { id: "m5", tag: "markers", type: "fill", q: "Li ___ dòmi kounye a.", a: "ap", opts: ["te", "ap", "pral", "pa"], en: "She's sleeping right now." },
    { id: "m6", tag: "markers", type: "fill", q: "Yo ___ ale lekòl yè.", a: "te", opts: ["te", "ap", "va", "pral"], en: "They went to school yesterday." },
    { id: "m7", tag: "markers", type: "fill", q: "Mwen ___ pral vini demen.", a: "pa", opts: ["pa", "te", "se", "ap"], en: "I'm not going to come tomorrow." },
    { id: "m8", tag: "markers", type: "fill", q: "Li ___ te vini.", a: "pa", opts: ["pa", "ap", "va", "ye"], en: "He didn't come." },
    { id: "m9", tag: "markers", type: "tr", q: "I'm going to eat.", a: "Mwen pral manje." },
    { id: "m10", tag: "markers", type: "tr", q: "I ate.", a: "Mwen te manje." },
    { id: "m11", tag: "markers", type: "tr", q: "I'm eating.", a: "Mwen ap manje." },
    { id: "m12", tag: "markers", type: "tr", q: "I will eat.", a: "Mwen va manje." },
    { id: "m13", tag: "markers", type: "tr", q: "He was hungry.", a: "Li te grangou." },
    { id: "m14", tag: "markers", type: "tr", q: "I eat rice every day.", a: "Mwen manje diri chak jou." },

    /* ---- pronouns, nou vs. ou ---- */
    { id: "p1", tag: "pronouns", type: "fill", q: "___ fatige. (We are tired.)", a: "Nou", opts: ["Nou", "Ou", "Yo", "Li"], en: "We are tired." },
    { id: "p2", tag: "pronouns", type: "fill", q: "___ fatige. (You are tired, one person.)", a: "Ou", opts: ["Nou", "Ou", "Yo", "Mwen"], en: "You are tired." },
    { id: "p3", tag: "pronouns", type: "fill", q: "___ ap vini? (Are you all coming?)", a: "Nou", opts: ["Nou", "Ou", "Li", "Yo"], en: "Are you all coming?" },
    { id: "p4", tag: "pronouns", type: "tr", q: "my book", a: "liv mwen" },
    { id: "p5", tag: "pronouns", type: "tr", q: "her house", a: "kay li" },
    { id: "p6", tag: "pronouns", type: "tr", q: "their car", a: "machin yo" },
    { id: "p7", tag: "pronouns", type: "tr", q: "our family", a: "fanmi nou" },
    { id: "p8", tag: "pronouns", type: "tr", q: "your friend (one person)", a: "zanmi ou" },
    { id: "p9", tag: "pronouns", type: "tr", q: "They're eating.", a: "Y ap manje." },
    { id: "p10", tag: "pronouns", type: "tr", q: "Are you coming? (one person)", a: "W ap vini?" },
    { id: "p11", tag: "pronouns", type: "tr", q: "We're going to school.", a: "N pral lekòl." },
    { id: "p12", tag: "pronouns", type: "tr", q: "I love coffee.", a: "M renmen kafe." },

    /* ---- articles ---- */
    { id: "a1", tag: "articles", type: "fill", q: "liv ___ (the book)", a: "la", opts: ["la", "a", "an", "nan"], en: "Ends in a consonant: la" },
    { id: "a2", tag: "articles", type: "fill", q: "kafe ___ (the coffee)", a: "a", opts: ["la", "a", "an", "nan"], en: "Ends in an oral vowel: a" },
    { id: "a3", tag: "articles", type: "fill", q: "pen ___ (the bread)", a: "an", opts: ["la", "a", "an", "nan"], en: "Ends in a nasal vowel: an" },
    { id: "a4", tag: "articles", type: "fill", q: "machin ___ (the car)", a: "nan", opts: ["la", "a", "an", "nan"], en: "Ends in a nasal consonant: nan" },
    { id: "a5", tag: "articles", type: "fill", q: "chanm ___ (the room)", a: "nan", opts: ["la", "a", "an", "nan"], en: "Ends in m: nan" },
    { id: "a6", tag: "articles", type: "fill", q: "bato ___ (the boat)", a: "a", opts: ["la", "a", "an", "nan"], en: "Ends in an oral vowel: a" },
    { id: "a7", tag: "articles", type: "fill", q: "chen ___ (the dog)", a: "an", opts: ["la", "a", "an", "nan"], en: "Ends in a nasal vowel: an" },
    { id: "a8", tag: "articles", type: "fill", q: "tab ___ (the table)", a: "la", opts: ["la", "a", "an", "nan"], en: "Ends in a consonant: la" },
    { id: "a9", tag: "articles", type: "fill", q: "kay mwen ___ (my house, the one)", a: "an", opts: ["la", "a", "an", "nan"], en: "Match the LAST word: mwen ends nasal" },
    { id: "a10", tag: "articles", type: "fill", q: "kay ou ___ (your house, the one)", a: "a", opts: ["la", "a", "an", "nan"], en: "Match the LAST word: ou ends in a vowel" },
    { id: "a11", tag: "articles", type: "tr", q: "the books", a: "liv yo" },
    { id: "a12", tag: "articles", type: "tr", q: "a book", a: "yon liv" },
    { id: "a13", tag: "articles", type: "tr", q: "this book", a: "liv sa a" },
    { id: "a14", tag: "articles", type: "tr", q: "these books", a: "liv sa yo" },
    { id: "a15", tag: "articles", type: "tr", q: "the red car", a: "machin wouj la" },

    /* ---- question words ---- */
    { id: "q1", tag: "questions", type: "tr", q: "Where do you live?", a: "Kote ou rete?" },
    { id: "q2", tag: "questions", type: "tr", q: "When are you going to come?", a: "Ki lè ou pral vini?" },
    { id: "q3", tag: "questions", type: "tr", q: "What are you doing?", a: "Ki sa ou ap fè?" },
    { id: "q4", tag: "questions", type: "tr", q: "Why didn't you come?", a: "Poukisa ou pa te vini?" },
    { id: "q5", tag: "questions", type: "tr", q: "How are you?", a: "Kijan ou ye?" },
    { id: "q6", tag: "questions", type: "tr", q: "How much does this cost?", a: "Konbyen sa a koute?" },
    { id: "q7", tag: "questions", type: "tr", q: "Who is that?", a: "Ki moun sa a?" },
    { id: "q8", tag: "questions", type: "tr", q: "Where is he?", a: "Kote li ye?" },
    { id: "q9", tag: "questions", type: "tr", q: "Are you hungry?", a: "Èske ou grangou?" },
    { id: "q10", tag: "questions", type: "fill", q: "___ ou rele? (What's your name?)", a: "Kijan", opts: ["Kijan", "Kote", "Konbyen", "Poukisa"], en: "What's your name? (How are you called?)" },
    { id: "q11", tag: "questions", type: "fill", q: "___ timoun ou genyen? (How many children do you have?)", a: "Konbyen", opts: ["Konbyen", "Ki moun", "Kote", "Ki lè"], en: "How many children do you have?" },

    /* ---- little words ---- */
    { id: "l1", tag: "little", type: "fill", q: "Li ___ doktè. (She is a doctor.)", a: "se", opts: ["se", "ye", "gen", "ap"], en: "se = is (thing = thing)" },
    { id: "l2", tag: "little", type: "fill", q: "Kijan ou ___? (How are you?)", a: "ye", opts: ["se", "ye", "gen", "pa"], en: "ye = is, at the end" },
    { id: "l3", tag: "little", type: "fill", q: "Mwen ___ de frè. (I have two brothers.)", a: "gen", opts: ["gen", "se", "ye", "pou"], en: "gen = have" },
    { id: "l4", tag: "little", type: "fill", q: "Diri ___ pwa. (Rice and beans.)", a: "ak", opts: ["ak", "nan", "pou", "se"], en: "ak = and, with" },
    { id: "l5", tag: "little", type: "fill", q: "Li ___ kay la. (He's in the house.)", a: "nan", opts: ["nan", "ak", "pou", "se"], en: "nan before a noun = in" },
    { id: "l6", tag: "little", type: "fill", q: "Sa a se ___ ou. (This is for you.)", a: "pou", opts: ["pou", "ak", "nan", "ye"], en: "pou = for, to" },
    { id: "l7", tag: "little", type: "tr", q: "She's beautiful.", a: "Li bèl." },
    { id: "l8", tag: "little", type: "tr", q: "I don't know.", a: "Mwen pa konnen." },
    { id: "l9", tag: "little", type: "tr", q: "My house is bigger than yours.", a: "Kay mwen pi gwo pase kay ou." },

    /* ---- travel together (Duolingo Unit 11) ---- */
    { id: "t1", tag: "travel", type: "tr", q: "Where is the airport?", a: "Kote ayewopò a ye?" },
    { id: "t2", tag: "travel", type: "tr", q: "I'm going to take the bus.", a: "M pral pran bis la." },
    { id: "t3", tag: "travel", type: "tr", q: "How much is the ticket?", a: "Konbyen tikè a koute?" },
    { id: "t4", tag: "travel", type: "tr", q: "We're traveling together.", a: "N ap vwayaje ansanm." },
    { id: "t5", tag: "travel", type: "tr", q: "Let's go!", a: "Ann ale!" },
    { id: "t6", tag: "travel", type: "tr", q: "I'm lost.", a: "Mwen pèdi." },
    { id: "t7", tag: "travel", type: "tr", q: "What time does the plane leave?", a: "Ki lè avyon an ap pati?" },
    { id: "t8", tag: "travel", type: "tr", q: "Turn left.", a: "Vire agoch." },
    { id: "t9", tag: "travel", type: "tr", q: "the suitcase", a: "valiz la" },
    { id: "t10", tag: "travel", type: "tr", q: "my passport", a: "paspò mwen" },
    { id: "t11", tag: "travel", type: "tr", q: "The hotel is near the beach.", a: "Otèl la toupre plaj la." },
    { id: "t12", tag: "travel", type: "tr", q: "I need water.", a: "Mwen bezwen dlo." },

    /* ---- everyday ---- */
    { id: "e1", tag: "everyday", type: "tr", q: "Good morning", a: "Bonjou" },
    { id: "e2", tag: "everyday", type: "tr", q: "Good evening", a: "Bonswa" },
    { id: "e3", tag: "everyday", type: "tr", q: "Thank you", a: "Mèsi" },
    { id: "e4", tag: "everyday", type: "tr", q: "Excuse me", a: "Eskize m" },
    { id: "e5", tag: "everyday", type: "tr", q: "I don't understand.", a: "Mwen pa konprann." },
    { id: "e6", tag: "everyday", type: "tr", q: "Speak slowly, please.", a: "Pale dousman, souple." },
    { id: "e7", tag: "everyday", type: "tr", q: "See you later.", a: "N a wè pita." },
    { id: "e8", tag: "everyday", type: "tr", q: "the children", a: "timoun yo" },
    { id: "e9", tag: "everyday", type: "tr", q: "today", a: "jodi a" },
    { id: "e10", tag: "everyday", type: "tr", q: "tomorrow", a: "demen" }
  ],

  /* Jo's rulebook (from "Kreyòl Parts of Speech Rulebook", 2026-10-20), in app form. */
  rules: [
    { title: "The pattern", intro: "Kreyòl verbs never change form. Small words in front of the verb tell you who, not and when. Build every sentence left to right: Who · Not · When · Action · What/where.",
      rows: [["Mwen te manje diri.", "I ate rice."], ["Li pa pral vini demen.", "He's not going to come tomorrow."], ["Nou ap travay kounye a.", "We're working right now."]] },
    { title: "Pronouns", intro: "One word does three jobs: I, me and my are all mwen. Only the position changes. Short forms are optional.",
      rows: [["mwen · m", "I · me · my"], ["ou · w", "you · your (one person)"], ["li · l", "he · she · it · his · her"], ["nou · n", "we · us · our · you all"], ["yo · y", "they · them · their"]],
      tips: ["Owner goes after the thing: liv mwen = my book, kay li = his/her house.", "nou = we (or you all), ou = you (one person). The extra n means more than one."] },
    { title: "Tense markers", intro: "The verb stays the same; one marker right before it sets the time.",
      rows: [["te", "past · Mwen te manje. (I ate.)"], ["ap", "happening now · Mwen ap manje. (I'm eating.)"], ["pral", "going to, soon · Mwen pral manje."], ["va", "will, later · Mwen va manje."], ["(none)", "habit or finished · Mwen manje diri chak jou."]],
      tips: ["Not goes first: pa comes before the marker. Li pa te vini. = He didn't come.", "te often shortens to t: M t ale. = I went.", "No “is” with describing words: Li grangou. = He's hungry."] },
    { title: "“The” goes after the noun", intro: "Its form matches the noun's last sound.",
      rows: [["oral consonant → la", "liv la · tab la · kay la"], ["oral vowel → a", "kafe a · bato a · papa a"], ["nasal vowel → an", "pen an · chen an · pantalon an"], ["m or n → nan (or lan)", "chanm nan · fanm nan · machin nan"]],
      tips: ["Plural: swap the article for yo. liv yo = the books.", "“A / an”: yon goes before. yon liv = a book.", "Match the last word: chanm mwen an · kay ou a."] },
    { title: "Pointing: sa a, sa yo", intro: "After the noun, replacing “the”. They never change form.",
      rows: [["liv sa a", "this book"], ["liv sa yo", "these books"], ["chemiz wouj sa a", "this red shirt"], ["Sa a se kay mwen.", "This is my house."]] },
    { title: "Adjectives and adverbs", intro: "Most describing words go after the noun; a short list goes before.",
      rows: [["yon machin wouj", "a red car (most adjectives after)"], ["yon gwo kay · yon ti chat", "gwo, ti, bon, bèl, move, vye go before"], ["machin wouj la", "the red car (“the” comes last)"], ["Kay mwen pi gwo pase kay ou.", "pi + word + pase = bigger than"], ["Li pale vit.", "adverbs after the verb or at the end"]] },
    { title: "Question words", intro: "Question word first, then normal order. Nothing flips.",
      rows: [["kote", "where · Kote ou rete?"], ["ki lè", "when · Ki lè ou pral vini?"], ["ki sa", "what · Ki sa ou ap fè?"], ["poukisa", "why · Poukisa ou pa te vini?"], ["kijan", "how · Kijan ou ye?"], ["konbyen", "how much · Konbyen sa a koute?"], ["ki moun", "who · Ki moun sa a?"]],
      tips: ["Yes/no: add Èske, or raise your voice. Èske ou grangou?", "No verb after the question? End with ye: Kote li ye?"] },
    { title: "Little words", intro: "The glue.",
      rows: [["pa", "not · Mwen pa konnen."], ["gen / genyen", "have; there is · Mwen gen de frè."], ["se", "is (thing = thing) · Li se doktè."], ["ye", "is, at the end · Kijan ou ye?"], ["ak", "and, with · Diri ak pwa."], ["nan", "in, at · Li nan kay la."], ["pou", "for, to · Sa a se pou ou."]],
      tips: ["nan before a noun = in; after a noun = the.", "No se before adjectives: Li bèl, not Li se bèl."] },
    { title: "5-second check before you send", intro: "",
      rows: [["Who?", "Right pronoun? (nou = we, ou = you)"], ["When?", "One marker right before the verb?"], ["Not?", "Is pa in front of the marker?"], ["The?", "Article after the noun, matching the last sound?"], ["Question?", "Question word first, then normal order?"], ["Describing?", "No se before an adjective?"]] }
  ]
};
