/* updater.js — lets the installed app fetch new versions of its own screens from your GitHub page.
   - Works only in the installed Android app (needs the CapacitorUpdater plugin). In a browser it does nothing.
   - The app always works with no signal: updates are checked quietly when you're online, and a new version is
     only used the NEXT time the app starts (or when you tap "Restart now").
   - Safety net: if a new version fails to start, the phone goes back to the previous one by itself, and that
     broken version is never downloaded again (publish a fixed one and it will be picked up). */
(function () {
  "use strict";
  var CFG = window.UPDATE_CONFIG || {};
  var BUILD = String(window.APP_BUILD || "0");
  var base = String(CFG.baseUrl || "").replace(/\/+$/, "");
  var configured = /^https:\/\/[^\s]+$/i.test(base) && !/PASTE|YOUR-/i.test(base);
  var state = { status: "idle", message: "", build: BUILD, readyId: null, readyVersion: null, lastCheck: 0 };
  var listeners = [], checking = null;

  function plugin() { return window.Capacitor && window.Capacitor.Plugins && window.Capacitor.Plugins.CapacitorUpdater; }
  function isNative() { try { return !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform()); } catch (e) { return false; } }
  function set(status, message) {
    state.status = status; state.message = message || "";
    listeners.slice().forEach(function (f) { try { f(api.getState()); } catch (e) {} });
    if (status === "ready") showBar();
  }
  function withTimeout(p, ms, what) {
    return new Promise(function (resolve, reject) {
      var t = setTimeout(function () { reject(new Error("Timed out " + what)); }, ms);
      p.then(function (v) { clearTimeout(t); resolve(v); }, function (e) { clearTimeout(t); reject(e); });
    });
  }

  /* ---- 1. tell the phone this version started properly (otherwise it rolls back) ---- */
  function confirmHealthy() {
    var p = plugin(); if (!p || !isNative() || !p.notifyAppReady) return;
    var tries = 0;
    (function poll() {
      // the home screen sets __benchReady only after it has drawn itself
      if (window.__benchReady) { try { p.notifyAppReady(); } catch (e) {} return; }
      if (++tries < 30) setTimeout(poll, 500);   // ~15 s, shorter than the plugin's 20 s timeout → no confirm = automatic rollback
    })();
  }

  /* ---- 2. the "update ready" bar ---- */
  function showBar() {
    if (document.getElementById("bench-update-bar")) return;
    var bar = document.createElement("div"); bar.id = "bench-update-bar";
    bar.style.cssText = "position:fixed;left:12px;right:12px;bottom:calc(12px + env(safe-area-inset-bottom,0px));z-index:99990;background:#141412;color:#DFDAD1;border:1px solid #92948D;border-radius:10px;padding:10px 12px;font:14px/1.3 system-ui,sans-serif;display:flex;gap:10px;align-items:center;box-shadow:0 4px 18px rgba(0,0,0,.35)";
    var txt = document.createElement("div"); txt.style.flex = "1"; txt.textContent = "Update downloaded. It will be used the next time you open the app.";
    var go = document.createElement("button"); go.textContent = "Restart now";
    go.style.cssText = "background:#92948D;color:#111;border:0;border-radius:7px;padding:8px 12px;font-weight:600;font-size:13px";
    var later = document.createElement("button"); later.textContent = "Later";
    later.style.cssText = "background:transparent;color:#bbb;border:1px solid #444;border-radius:7px;padding:8px 10px;font-size:13px";
    go.onclick = function () { api.restartNow(); };
    later.onclick = function () { bar.remove(); };
    bar.appendChild(txt); bar.appendChild(go); bar.appendChild(later); document.body.appendChild(bar);
  }

  /* ---- 3. check, download, queue ---- */
  function readVersionFile() {
    var url = base + "/version.json?t=" + Date.now();
    return withTimeout(fetch(url, { cache: "no-store" }), 12000, "checking for updates").then(function (r) {
      if (!r.ok) throw new Error("Update check failed (" + r.status + ")");
      return r.json();
    });
  }
  function checkNow(manual) {
    if (checking) return checking;
    state.lastCheck = Date.now();
    var p = plugin();
    if (!isNative() || !p) { set("unavailable", "Updates work in the installed app, not in a browser."); return Promise.resolve(api.getState()); }
    if (!configured) { set("not-configured", "Updates aren't set up yet (no GitHub address in update-config.js)."); return Promise.resolve(api.getState()); }
    if (typeof navigator !== "undefined" && navigator.onLine === false) { set("offline", "No connection — will check again when you're online."); return Promise.resolve(api.getState()); }
    set("checking", "Checking for updates…");
    checking = readVersionFile().then(function (v) {
      var remote = String(v && v.version || ""), file = String(v && v.file || "");
      if (!/^\d{14}$/.test(remote) || !/^[A-Za-z0-9._-]+\.zip$/.test(file)) throw new Error("The update file on GitHub isn't valid.");
      if (remote <= BUILD) { set("current", "You have the latest version."); return; }
      return p.list().then(function (res) {
        var all = (res && res.bundles) || [];
        var same = all.filter(function (b) { return b.version === remote; });
        if (same.some(function (b) { return b.status === "error"; })) { set("current", "You have the latest working version."); return; }   // that version failed before — wait for a fixed one
        var have = same.filter(function (b) { return b.status === "success" || b.status === "pending"; })[0];
        if (have) return have;
        set("downloading", "Downloading update…");
        return withTimeout(p.download({ url: base + "/" + file, version: remote }), 180000, "downloading the update");
      }).then(function (bundle) {
        if (!bundle) return;
        return p.next({ id: bundle.id }).then(function () {
          state.readyId = bundle.id; state.readyVersion = remote;
          set("ready", "Update downloaded — it will be used next time you open the app.");
        });
      });
    }).catch(function (e) {
      set(manual ? "error" : "idle", manual ? ("Couldn't update: " + (e && e.message || e)) : "");
    }).then(function () { checking = null; return api.getState(); });
    return checking;
  }

  var api = {
    build: BUILD,
    getState: function () { return { status: state.status, message: state.message, build: state.build, readyVersion: state.readyVersion, configured: configured, native: isNative() }; },
    onChange: function (cb) { listeners.push(cb); return function () { var i = listeners.indexOf(cb); if (i >= 0) listeners.splice(i, 1); }; },
    checkNow: checkNow,
    restartNow: function () { var p = plugin(); if (p && state.readyId) { try { p.set({ id: state.readyId }); } catch (e) {} } }
  };
  window.BenchUpdater = api;

  /* ---- 4. when to look ---- */
  function maybeCheck() { if (document.hidden) return; if (Date.now() - state.lastCheck < 30 * 60 * 1000) return; checkNow(false); }
  confirmHealthy();
  window.addEventListener("load", function () { setTimeout(maybeCheck, 4000); });
  window.addEventListener("online", function () { setTimeout(function () { state.lastCheck = 0; maybeCheck(); }, 1500); });
  document.addEventListener("visibilitychange", function () { if (!document.hidden) setTimeout(maybeCheck, 1500); });
})();
