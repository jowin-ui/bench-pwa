/* Where the app looks for new versions of itself.
   Paste your GitHub Pages address between the quotes (no trailing slash), for example:
    https://jowin-ui.github.io/bench-updates/
   Leave it as is to keep updates turned off — the app works normally either way. */
window.UPDATE_CONFIG = {
  baseUrl: "https://jowin-ui.github.io/bench-updates"
};
